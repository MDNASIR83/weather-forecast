const apikey = "aef55f23253a71c537b50e7c804127cc";
const apiurl ="https://api.openweathermap.org/data/2.5/weather?&units=metric";
const  weather_icon = document.querySelector(".weather_icon");
var cityname;
async function checkweather(){
   debugger;
    const response = await fetch(apiurl +'&q='+cityname +`&appid=aef55f23253a71c537b50e7c804127cc`);
    debugger;
    var data = await response.json();
    console.log(data);
    document.querySelector(".city").innerHTML = data.name;
    document.querySelector(".wind").innerHTML = data.wind.speed +"km/h";
    document.querySelector(".temp").innerHTML = Math.round(data.main.temp) + "°C" ;
    document.querySelector(".humidity").innerHTML = data.main.humidity +"%";
    if(data.weather[0].main == "Clouds")
{
    weather_icon.src = "weather-app-img/images/clouds.png";
}
else if(data.weather[0].main == "Drizzle"){
    weather_icon.src = "weather-app-img/images/drizzle.png";
}
else if(data.weather[0].main == "Rain"){
    weather_icon.src = "weather-app-img/images/rain.png";
}
else if(data.weather[0].main == "Snow"){
    weather_icon.src = "weather-app-img/images/snow.png";
}
else if(data.weather[0].main == "Mist"){
    weather_icon.src = "weather-app-img/images/mist.png";
}
else if(data.weather[0].main == "Clear"){
    weather_icon.src = "weather-app-img/images/clear.png";
}
else if(data.weather[0].main == "Haze"){
    weather_icon.src = "weather-app-img/images/haze.png";
}
};
$(document).ready(function(){
$("#button").click(function(){
    debugger;
cityname = $("#txt").val();
checkweather();

});
});